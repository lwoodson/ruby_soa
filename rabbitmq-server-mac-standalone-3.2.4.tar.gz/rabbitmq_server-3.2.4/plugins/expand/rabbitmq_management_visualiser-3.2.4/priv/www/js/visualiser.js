dispatcher_add(function(sammy) {});

NAVIGATION['Visualiser'] = ['visualiser/', "management"];
